"""为同一个 6 m/s 热敏珠启动工况准备可重建的本机输入缓存。"""
import argparse
from contextlib import contextmanager
import gzip
import json
import msvcrt
import os
from pathlib import Path
import shutil
import tempfile
import zipfile

for variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"
import numpy as np

from cm011TunnelSector import mesh, write_volume
from thermistorBead import D, ROOT, wall, read, sha
from thermistorNearWall import FIELDS, geometry, read_grid, refine
from thermistorSeedRecovery import CASE, COARSE_SEED, identical, recover, write_seed
from thermistorStartupSurface import columns, write

CACHE = ROOT/"outputs/thermistor_inputs/B6-56"
COARSE = CACHE/"mesh48"
GRID = CACHE/"grid56"
BUILD = CACHE/"observer"
PREVIOUS = ROOT/"docs/validation/v293"
GRID_SPEC = read(PREVIOUS/"evidence/grid.json")
OBSERVER_SPEC = read(PREVIOUS/"evidence/readout_build.json")
COARSE_MESH = "673151f2681de2a150f7de689bea3096e3b6fa6d9b91ddb80dc635e563fe951c"
COARSE_NODES = "2617470c05476d59a00ad33c509d6c9a5a2db7ce1d22b0ce86ae61d9ae0392b6"
BODY_SHA = "5e66bb2f70f0774b8ebb87a77b76061fc84b89b9f379d54e90879e81628bf62f"
GEOM_SHA = "1587ac97a3ed59ab75ce2b35266039c46c58ef837480f66fcb6cdeb2a2cfb7fe"


@contextmanager
def installation_lock():
    CACHE.mkdir(parents=True,exist_ok=True)
    with (CACHE/"install.lock").open("a+b") as f:
        f.seek(0)
        try:
            msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
        except OSError as exc:
            raise RuntimeError("另一任务正在准备热敏珠输入，请在准备结束后使用缓存。") from exc
        try:
            yield
        finally:
            f.seek(0)
            msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)


def create_coarse(out):
    """由名义尺寸建立全周网格和节点映射，从随工程发布的同一几何恢复原面编号。"""
    _,xyz,_,_,ids,cells,markers,_ = mesh(np.linspace(0,2*np.pi,49),2,48,wall(64),20.,D)
    write_volume(out,xyz,cells,markers)
    np.savez_compressed(out/"nodes.npz",xyz=xyz,ids=ids)
    identical(out/"mesh.su2",COARSE_MESH)
    identical(out/"nodes.npz",COARSE_NODES)
    with zipfile.ZipFile(ROOT/"cases/thermistor_b/startup_6ms.zip") as archive:
        (out/"body.json").write_bytes(archive.read("body.json"))
    identical(out/"body.json",BODY_SHA)


def coarse_grid():
    if not COARSE.exists():
        work = Path(tempfile.mkdtemp(prefix="mesh48-",dir=CACHE))
        create_coarse(work)
        work.rename(COARSE)
    for name, digest in (("mesh.su2",COARSE_MESH),("nodes.npz",COARSE_NODES),("body.json",BODY_SHA)):
        identical(COARSE/name,digest)


def bound_source(name):
    files = {"geometry.json": (CASE/"geometry.json",GEOM_SHA), "body.json": (COARSE/"body.json",BODY_SHA),
             "nodes.npz": (COARSE/"nodes.npz",COARSE_NODES)}
    return identical(*files[name])


def fine_grid(out, seed):
    """在重建的原网最内八个区间增加中点，重算对偶体积并逐字节核对全部输入。"""
    xyz,cells,markers = read_grid(COARSE/"mesh.su2")
    with np.load(COARSE/"nodes.npz") as z:
        assert np.array_equal(z["xyz"],xyz)
        ids=z["ids"].reshape(49,49,65)
    new_xyz,fine,parent,pairs,new_cells = refine(xyz,ids,cells)
    write_volume(out,new_xyz,new_cells,markers)
    split=np.bincount(parent,minlength=len(cells))==2
    dual,_,_,geom=geometry(new_xyz,new_cells,markers,split[parent])
    assert geom==GRID_SPEC["newGeometry"]
    _,indices=np.unique(ids[:,0].ravel(),return_index=True)
    first=ids[:,1].ravel()[indices]
    near=fine[:,1].ravel()[indices]
    np.savez_compressed(out/"nodes.npz",xyz=new_xyz,ids=fine.reshape(49,-1),originalFirst=first,
                        refinedFirst=near,oldGridNodes=len(xyz),dualVolume=dual)
    old=columns(identical(seed,COARSE_SEED),FIELDS)
    values=np.vstack((old[:,4:],old[pairs,4:].mean(axis=1)))
    write_seed(out/"seed_00000.csv",np.column_stack((np.arange(len(new_xyz)),new_xyz,values)))
    # 此处复用已通过的科学审核记录；三份文件须与当时实际参与审核的字节一致。
    for name,key in (("mesh.su2","gridSHA256"),("nodes.npz","nodeMapSHA256"),("seed_00000.csv","seedSHA256")):
        identical(out/name,GRID_SPEC[key])
    shutil.copyfile(PREVIOUS/"evidence/grid.json",out/"grid.json")


def grid_info(grid=GRID):
    assert grid.resolve()==GRID and read(grid/"grid.json")==GRID_SPEC
    for name,key in (("mesh.su2","gridSHA256"),("nodes.npz","nodeMapSHA256"),("seed_00000.csv","seedSHA256")):
        identical(grid/name,GRID_SPEC[key])
    return GRID_SPEC


def ensure_grid():
    with installation_lock():
        coarse_grid()
        if not GRID.exists():
            # 本项目自身的数值初值。在新安装上可从冷态构造，原安装可复用有准确指纹的旧态。
            seed = CACHE/"initial"/"seed_00000.csv"
            legacy = ROOT/"outputs/v289_validation/window01/seed_00000.csv"
            if not seed.is_file():
                pool=Path(tempfile.mkdtemp(prefix="initial-",dir=CACHE))
                if legacy.is_file():
                    shutil.copyfile(identical(legacy,COARSE_SEED),pool/"seed_00000.csv")
                    write(pool/"seed_recovery.json",dict(source="verified-local-migration",seedSHA256=COARSE_SEED))
                else:
                    recover(pool,COARSE)
                pool.rename(seed.parent)
            work=Path(tempfile.mkdtemp(prefix="grid56-",dir=CACHE))
            fine_grid(work,seed)
            work.rename(GRID)
        grid_info()


if __name__=="__main__":
    ensure_grid()
