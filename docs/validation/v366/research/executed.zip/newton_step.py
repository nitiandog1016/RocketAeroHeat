"""同一物理方程采用 SU2 内置的矩阵自由非线性迭代，读取实际终态。"""
import argparse
from pathlib import Path
import shutil
import numpy as np
from fixed_step import check as fixed_check
from physical_step import (ARCHIVE, BASE, DOC, EXE, EXE_SHA, OLD, ORIGIN, RES, ROOT, STEPS,
                           config, numbers, observe, read, save, sha, step_config, terminal, vtk_tokens)


def options(kind):
    cfg=step_config(*STEPS[kind])
    cfg.update(NEWTON_KRYLOV="YES",NEWTON_KRYLOV_IPARAM="(0,3,1)",NEWTON_KRYLOV_DPARAM="(0,0.1,-6,1e-6,1)",
               CFL_ADAPT="NO",CFL_NUMBER="100",LINEAR_SOLVER_ERROR="0.05",INNER_ITER="250",
               HISTORY_OUTPUT="(ITER,TIME_DOMAIN,RMS_RES,MAX_RES,HEAT,CFL_NUMBER,LINSOL)",
               VOLUME_OUTPUT="(COORDINATES,SOLUTION,PRIMITIVE,RESIDUAL)")
    return cfg


def check(folder,kind):
    r=terminal(folder);dt,i=STEPS[kind]
    assert all(sha(Path(p))==h for p,h in r["inputSHA256"].items())
    assert config(folder/"case.cfg")==options(kind)
    hist=folder/f"history_{i:05d}.csv";h=numbers(hist);n=len(h["Inner_Iter"])
    np.testing.assert_array_equal(h["Inner_Iter"],np.arange(n))
    assert np.all(h["Time_Iter"]==i) and np.allclose(h["Time_Step"],dt,rtol=1e-8,atol=0)
    residuals=np.column_stack([h[k] for k in RES])
    assert np.isfinite(residuals).all()
    end=folder/f"restart_{i:05d}.csv";seed=folder/f"seed_{i-1:05d}.csv";surface=folder/f"surface_{i:05d}.vtk"
    a,b=numbers(end),numbers(seed)
    for k in ("PointID","x","y"):np.testing.assert_array_equal(a[k],b[k])
    rho=a["Density"]
    assert len(rho)==9701 and np.isfinite(np.column_stack(list(a.values()))).all() and min(rho)>0
    p=.4*(a["Energy"]-.5*(a["Momentum_x"]**2+a["Momentum_y"]**2)/rho)
    np.testing.assert_allclose(p,a["Pressure"],rtol=1e-10)
    np.testing.assert_allclose(p/rho,a["Temperature"],rtol=1e-10)
    assert min(p)>0 and not np.array_equal(a["Energy"],b["Energy"])
    assert np.all(a["Momentum_x"][:109]==0) and np.all(a["Momentum_y"][:109]==0)
    xyz,f=vtk_tokens(surface);assert len(xyz)==109 and "Heat_Flux" in f
    return dict(branch=kind,dtSeconds=dt,elapsedFromSeedSeconds=i*dt,nativeCurTimeSeconds=float(h["Cur_Time"][-1]),
        innerIterations=n,last20Max=dict(zip(RES,residuals[-20:].max(axis=0).tolist())),
        innerPassed=bool(n>=20 and residuals[-20:].max() < -8),seedSHA256=sha(seed),frameSHA256=sha(end),
        wallSHA256=sha(surface),historySHA256=sha(hist),cfgSHA256=sha(folder/"case.cfg"),meshSHA256=sha(folder/"mesh.su2"),
        seconds=r["elapsedSeconds"],peakRSSBytes=r["peakFamilyRSSBytes"])


def run(out,kind):
    out=out.resolve();out.relative_to(BASE)
    previous="full" if kind=="full" else "half1"
    old=fixed_check(BASE/"time02"/previous,previous)
    assert not old["innerPassed"] and old["seedSHA256"]==sha(ORIGIN)
    dt,i=STEPS[kind];source=ORIGIN
    if kind=="half2":
        parent=check(out/"half1","half1");assert parent["innerPassed"] and parent["seedSHA256"]==sha(ORIGIN)
        source=out/"half1/restart_00001.csv"
    folder=out/kind;folder.mkdir(parents=True,exist_ok=False)
    cfg=folder/"case.cfg";cfg.write_text("".join(f"{k}= {v}\n" for k,v in options(kind).items()),encoding="ascii")
    mesh=folder/"mesh.su2";seed=folder/f"seed_{i-1:05d}.csv"
    shutil.copyfile(OLD/"mesh.su2",mesh);shutil.copyfile(source,seed)
    assert sha(seed)==sha(source) and sha(mesh)==old["meshSHA256"] and sha(EXE)==EXE_SHA
    paths=[mesh,seed,cfg,source,EXE,ARCHIVE,OLD/"case.cfg",OLD/"condition.json",DOC/"PLAN.md",DOC/"NONLINEAR.md",
           DOC/"physical_step.py",DOC/"fixed_step.py",Path(__file__),ROOT/"scripts/runSU2NativeDebugger.py"]
    observe([str(EXE),cfg.name,"--threads","2"],folder,{str(p):sha(p) for p in paths},150,64*1024**2)
    record=check(folder,kind);save(folder/"step.json",record)
    print(kind,record["innerIterations"],record["last20Max"],record["innerPassed"],flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("out",type=Path);p.add_argument("kind",choices=STEPS)
    args=p.parse_args();run(args.out,args.kind)
