"""在相同物理步和起始场下独立测量固定伪时间 CFL 的作用。"""
import argparse
from pathlib import Path
import shutil
import numpy as np
from physical_step import (ARCHIVE, BASE, DOC, EXE, EXE_SHA, OLD, ORIGIN, RES, ROOT, STEPS, config,
                           inspect, numbers, observe, read, save, sha, step_config, terminal)


def settings(kind):
    cfg=step_config(*STEPS[kind])
    cfg.update(CFL_ADAPT="NO",HISTORY_OUTPUT="(ITER,TIME_DOMAIN,RMS_RES,HEAT,CFL_NUMBER,LINSOL)")
    return cfg


def check(folder,kind):
    receipt=terminal(folder);dt,i=STEPS[kind]
    assert all(sha(Path(p))==h for p,h in receipt["inputSHA256"].items())
    assert config(folder/"case.cfg")==settings(kind)
    h=numbers(folder/f"history_{i:05d}.csv")
    n=len(h["Inner_Iter"]);np.testing.assert_array_equal(h["Inner_Iter"],np.arange(n))
    assert np.all(h["Time_Iter"]==i) and np.allclose(h["Time_Step"],dt,rtol=1e-8,atol=0)
    assert set(k for k in h if k.startswith("rms["))==set(RES)
    assert np.isfinite(np.column_stack([h[k] for k in RES])).all()
    window={k:float(max(h[k][-20:])) for k in RES}
    end=folder/f"restart_{i:05d}.csv";seed=folder/f"seed_{i-1:05d}.csv"
    a,b=numbers(end),numbers(seed)
    for k in ("PointID","x","y"):
        np.testing.assert_array_equal(a[k],b[k])
    assert len(a["x"])==9701 and np.isfinite(np.column_stack(list(a.values()))).all()
    rho=a["Density"];p=.4*(a["Energy"]-.5*(a["Momentum_x"]**2+a["Momentum_y"]**2)/rho)
    assert min(rho)>0 and min(p)>0 and not np.array_equal(a["Energy"],b["Energy"])
    np.testing.assert_allclose(p,a["Pressure"],rtol=1e-10)
    np.testing.assert_allclose(p/rho,a["Temperature"],rtol=1e-10)
    assert np.all(a["Momentum_x"][:109]==0) and np.all(a["Momentum_y"][:109]==0)
    clocks=np.unique(h["Cur_Time"]);assert len(clocks)==1
    # 单步独立进程的物理时钟以该进程记录为准；串联经过时间由通过的父帧和步长共同确定。
    return dict(branch=kind,dtSeconds=dt,elapsedFromSeedSeconds=i*dt,nativeCurTimeSeconds=float(clocks[0]),
                innerIterations=n,last20Max=window,innerPassed=bool(n>=20 and max(window.values())< -8),
                seedSHA256=sha(seed),frameSHA256=sha(end),wallSHA256=sha(folder/f"surface_{i:05d}.vtk"),
                historySHA256=sha(folder/f"history_{i:05d}.csv"),meshSHA256=sha(folder/"mesh.su2"),
                cfgSHA256=sha(folder/"case.cfg"),seconds=receipt["elapsedSeconds"],peakRSSBytes=receipt["peakFamilyRSSBytes"])


def run(out,kind):
    out=out.resolve();out.relative_to(BASE)
    dt,i=STEPS[kind];source=ORIGIN
    first="half1" if kind=="half2" else kind
    initial=inspect(BASE/"time01"/first,first)
    assert not initial["innerPassed"] and initial["seedSHA256"]==sha(ORIGIN)
    if kind=="half2":
        parent=check(out/"half1","half1")
        assert parent["innerPassed"] and parent["seedSHA256"]==sha(ORIGIN)
        source=out/"half1/restart_00001.csv"
    folder=out/kind;folder.mkdir(parents=True,exist_ok=False)
    mesh=folder/"mesh.su2";seed=folder/f"seed_{i-1:05d}.csv";cfg=folder/"case.cfg"
    shutil.copyfile(OLD/"mesh.su2",mesh);shutil.copyfile(source,seed)
    assert sha(seed)==sha(source) and sha(mesh)==initial["meshSHA256"] and sha(EXE)==EXE_SHA
    cfg.write_text("".join(f"{k}= {v}\n" for k,v in settings(kind).items()),encoding="ascii")
    paths=[mesh,seed,cfg,source,EXE,ARCHIVE,OLD/"case.cfg",OLD/"condition.json",DOC/"PLAN.md",
           DOC/"RECOVERY.md",DOC/"physical_step.py",Path(__file__),ROOT/"scripts/runSU2NativeDebugger.py"]
    observe([str(EXE),cfg.name,"--threads","2"], folder,{str(p):sha(p) for p in paths},150,64*1024**2)
    r=check(folder,kind);save(folder/"step.json",r)
    print(kind,r["innerIterations"],r["last20Max"],r["innerPassed"],flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("out",type=Path);p.add_argument("kind",choices=STEPS)
    args=p.parse_args();run(args.out,args.kind)
